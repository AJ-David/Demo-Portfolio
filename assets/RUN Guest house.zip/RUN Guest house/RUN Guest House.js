// Navigation Functionality
const navbar = document.querySelector('.navbar');
const menuToggle = document.querySelector('.menu-toggle');
const navLinks = document.querySelector('.nav-links');

window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

menuToggle.addEventListener('click', () => {
    navLinks.classList.toggle('active');
});

document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        navLinks.classList.remove('active');
    });
});

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            window.scrollTo({
                top: target.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// Scroll Animation for Booking Section
const bookingForm = document.querySelector('.booking-form-container');

window.addEventListener('scroll', () => {
    if (isElementInViewport(bookingForm)) {
        bookingForm.classList.add('visible');
    }
});

function isElementInViewport(el) {
    const rect = el.getBoundingClientRect();
    return (
        rect.top <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.bottom >= 0
    );
}

// Date Picker Functionality
const checkInInput = document.getElementById('check-in');
const checkOutInput = document.getElementById('check-out');
const checkInCalendar = document.getElementById('check-in-calendar');
const checkOutCalendar = document.getElementById('check-out-calendar');
const checkInDaysContainer = document.getElementById('check-in-days');
const checkOutDaysContainer = document.getElementById('check-out-days');

const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
let currentDate = new Date();
let selectedCheckInDate = null;
let selectedCheckOutDate = null;
let currentCheckInMonth = currentDate.getMonth();
let currentCheckInYear = currentDate.getFullYear();
let currentCheckOutMonth = currentDate.getMonth();
let currentCheckOutYear = currentDate.getFullYear();

// Show calendar when input is clicked
checkInInput.addEventListener('click', () => {
    checkInCalendar.classList.toggle('show');
    checkOutCalendar.classList.remove('show');
    renderCalendar(currentCheckInMonth, currentCheckInYear, checkInDaysContainer, 'check-in');
});

checkOutInput.addEventListener('click', () => {
    checkOutCalendar.classList.toggle('show');
    checkInCalendar.classList.remove('show');
    renderCalendar(currentCheckOutMonth, currentCheckOutYear, checkOutDaysContainer, 'check-out');
});

// Close calendar when clicking outside
document.addEventListener('click', (e) => {
    if (!e.target.closest('.date-picker') && !e.target.classList.contains('day')) {
        checkInCalendar.classList.remove('show');
        checkOutCalendar.classList.remove('show');
    }
});

// Navigate between months
document.querySelector('#check-in-calendar .prev-month').addEventListener('click', () => {
    currentCheckInMonth--;
    if (currentCheckInMonth < 0) {
        currentCheckInMonth = 11;
        currentCheckInYear--;
    }
    updateCalendarHeader(document.querySelector('#check-in-calendar .calendar-header h4'), currentCheckInMonth, currentCheckInYear);
    renderCalendar(currentCheckInMonth, currentCheckInYear, checkInDaysContainer, 'check-in');
});

document.querySelector('#check-in-calendar .next-month').addEventListener('click', () => {
    currentCheckInMonth++;
    if (currentCheckInMonth > 11) {
        currentCheckInMonth = 0;
        currentCheckInYear++;
    }
    updateCalendarHeader(document.querySelector('#check-in-calendar .calendar-header h4'), currentCheckInMonth, currentCheckInYear);
    renderCalendar(currentCheckInMonth, currentCheckInYear, checkInDaysContainer, 'check-in');
});

document.querySelector('#check-out-calendar .prev-month').addEventListener('click', () => {
    currentCheckOutMonth--;
    if (currentCheckOutMonth < 0) {
        currentCheckOutMonth = 11;
        currentCheckOutYear--;
    }
    updateCalendarHeader(document.querySelector('#check-out-calendar .calendar-header h4'), currentCheckOutMonth, currentCheckOutYear);
    renderCalendar(currentCheckOutMonth, currentCheckOutYear, checkOutDaysContainer, 'check-out');
});

document.querySelector('#check-out-calendar .next-month').addEventListener('click', () => {
    currentCheckOutMonth++;
    if (currentCheckOutMonth > 11) {
        currentCheckOutMonth = 0;
        currentCheckOutYear++;
    }
    updateCalendarHeader(document.querySelector('#check-out-calendar .calendar-header h4'), currentCheckOutMonth, currentCheckOutYear);
    renderCalendar(currentCheckOutMonth, currentCheckOutYear, checkOutDaysContainer, 'check-out');
});

function updateCalendarHeader(headerElement, month, year) {
    headerElement.textContent = `${months[month]} ${year}`;
}

function renderCalendar(month, year, container, type) {
    container.innerHTML = '';
    
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Create empty slots for days before the first day of month
    for (let i = 0; i < firstDay; i++) {
        const dayElement = document.createElement('div');
        dayElement.classList.add('day', 'inactive');
        container.appendChild(dayElement);
    }
    
    // Create days of the month
    for (let i = 1; i <= daysInMonth; i++) {
        const dayElement = document.createElement('div');
        dayElement.classList.add('day');
        dayElement.textContent = i;
        
        const currentDateObj = new Date();
        const calendarDate = new Date(year, month, i);
        
        // Disable past dates
        if (calendarDate < new Date(currentDateObj.getFullYear(), currentDateObj.getMonth(), currentDateObj.getDate())) {
            dayElement.classList.add('inactive');
        } else {
            // Check if this day is today
            if (i === currentDateObj.getDate() && month === currentDateObj.getMonth() && year === currentDateObj.getFullYear()) {
                dayElement.classList.add('today');
            }
            
            // Check if this day is selected
            if (type === 'check-in' && selectedCheckInDate && 
                i === selectedCheckInDate.getDate() && 
                month === selectedCheckInDate.getMonth() && 
                year === selectedCheckInDate.getFullYear()) {
                dayElement.classList.add('selected');
            }
            
            if (type === 'check-out' && selectedCheckOutDate && 
                i === selectedCheckOutDate.getDate() && 
                month === selectedCheckOutDate.getMonth() && 
                year === selectedCheckOutDate.getFullYear()) {
                dayElement.classList.add('selected');
            }
            
            // Add click event to select date
            dayElement.addEventListener('click', () => {
                const selectedDate = new Date(year, month, i);
                
                if (type === 'check-in') {
                    selectedCheckInDate = selectedDate;
                    checkInInput.value = formatDate(selectedDate);
                    checkInCalendar.classList.remove('show');
                    
                    // If check-out date is before check-in date, reset check-out
                    if (selectedCheckOutDate && selectedCheckOutDate <= selectedCheckInDate) {
                        selectedCheckOutDate = null;
                        checkOutInput.value = '';
                    }
                } else {
                    // Don't allow check-out date before check-in date
                    if (selectedCheckInDate && selectedDate < selectedCheckInDate) {
                        alert('Check-out date cannot be before check-in date');
                        return;
                    }
                    
                    selectedCheckOutDate = selectedDate;
                    checkOutInput.value = formatDate(selectedDate);
                    checkOutCalendar.classList.remove('show');
                }
                
                // Re-render both calendars
                renderCalendar(currentCheckInMonth, currentCheckInYear, checkInDaysContainer, 'check-in');
                renderCalendar(currentCheckOutMonth, currentCheckOutYear, checkOutDaysContainer, 'check-out');
            });
        }
        
        container.appendChild(dayElement);
    }
}

function formatDate(date) {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
}

// Initialize calendars
updateCalendarHeader(document.querySelector('#check-in-calendar .calendar-header h4'), currentCheckInMonth, currentCheckInYear);
updateCalendarHeader(document.querySelector('#check-out-calendar .calendar-header h4'), currentCheckOutMonth, currentCheckOutYear);
renderCalendar(currentCheckInMonth, currentCheckInYear, checkInDaysContainer, 'check-in');
renderCalendar(currentCheckOutMonth, currentCheckOutYear, checkOutDaysContainer, 'check-out');

// Form Submission
document.getElementById('booking-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Basic form validation
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const checkIn = document.getElementById('check-in').value;
    const checkOut = document.getElementById('check-out').value;
    const guests = document.getElementById('guests').value;
    const roomType = document.getElementById('room-type').value;
    
    if (!name || !email || !checkIn || !checkOut || !guests || !roomType) {
        alert('Please fill in all required fields.');
        return;
    }
    
    // Simulate form submission with animation
    const submitBtn = document.querySelector('.submit-btn');
    submitBtn.textContent = 'Processing...';
    submitBtn.disabled = true;
    
    setTimeout(() => {
        // Display success message
        const formContainer = document.querySelector('.booking-form-container');
        formContainer.innerHTML = `
            <div style="text-align: center; padding: 50px 20px;">
                <div style="font-size: 5rem; color: var(--secondary); margin-bottom: 20px;">✓</div>
                <h2 style="color: var(--secondary); margin-bottom: 15px;">Booking Request Received!</h2>
                <p style="color: var(--white); margin-bottom: 20px;">Thank you, ${name}! We've received your booking request for the ${roomType.charAt(0).toUpperCase() + roomType.slice(1)} Room from ${checkIn} to ${checkOut}.</p>
                <p style="color: var(--white); margin-bottom: 30px;">A confirmation email has been sent to ${email}. We'll contact you shortly to finalize your reservation.</p>
                <a href="RUN Guest House Index.html" class="btn btn-secondary" style="margin-top: 20px;">Return to Home</a>
            </div>
        `;
    }, 2000);
});

// Add animation effects on page load
window.addEventListener('load', () => {
    // Check if sbooking section is in viewport on load
    if (isElementInViewport(bookingForm)) {
        bookingForm.classList.add('visible');
    }
});

// Newsletter form submission
const newsletterForm = document.getElementById('newsletter-form');
    
newsletterForm.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const emailInput = this.querySelector('.newsletter-input');
  const submitButton = this.querySelector('.newsletter-btn');
  
  // Simple validation
  if (emailInput.value.trim() !== '') {
    // Visual feedback
    submitButton.textContent = '✓';
    submitButton.classList.add('pulse');
    
    // Reset button after 2 seconds
    setTimeout(function() {
      submitButton.textContent = '→';
      submitButton.classList.remove('pulse');
      emailInput.value = '';
    }, 2000);
    
    // Here you would typically send the data to your server
    console.log('Newsletter subscription for:', emailInput.value);
  }
});