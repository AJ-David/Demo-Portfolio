function submitBooking(event) {
    event.preventDefault();
    const name = document.getElementById('guest-name').value;
    const room = document.getElementById('room-type').value;
    const checkIn = document.getElementById('check-in').value;
    const nights = document.getElementById('nights').value;
    console.log(`Booking Submitted: ${name}, Room: ${room}, Check-In: ${checkIn}, Nights: ${nights}`);
    alert('Thank you, ' + name + '! Your booking request has been submitted.');
    document.getElementById('booking-form').reset();
}

function submitContact(event) {
    event.preventDefault();
    const name = document.getElementById('contact-name').value;
    const email = document.getElementById('contact-email').value;
    const message = document.getElementById('contact-message').value;
    console.log(`Contact Form Submitted: Name: ${name}, Email: ${email}, Message: ${message}`);
    alert('Thank you, ' + name + '! Your message has been sent.');
    document.getElementById('contact-form-element').reset();
}